t = -1:0.01:1;      
unitstep = t == 0; 
figure;
stem(t, unitstep);
title('Unit Step Function');
xlabel('Time');
ylabel('Amplitude');

    
unitstep = t >= 0; 
figure;
stem(t, unitstep);
title('Unit Step Function');
xlabel('Time');
ylabel('Amplitude');

t=0:0.1:2*pi;
figure;
plot(t,sin(t))
title('Unit Step Function');
xlabel('Time');
ylabel('Amplitude');


figure;
plot(t,cos(t))
title('Unit Step Function');
xlabel('Time');
ylabel('Amplitude');

t=0:0.1:10;
figure;
stem(t,sawtooth(t))
title('Unit Step Function');
xlabel('Time');
ylabel('Amplitude');