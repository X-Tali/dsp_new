num = 1;
den = [1 2];
H = tf(num, den);
impulse(H)
title ('Impulse Response of H(s) = 1/(s+2)');
xlabel ('Time (s)');
ylabel ('Amplitude');
