rp = input('Enter the passband ripple: ');
rs = input('Enter the stopband ripple: ');
wp = input('Enter the passband frequency: ');
ws = input('Enter the stopband frequency: ');
fs = input('Enter the sampling frequency: ');

w1 = 2 * wp / fs;
w2 = 2 * ws / fs;

[n, wn] = buttord(w1, w2, rp, rs);

[b, a] = butter(n, wn, 'low');

[H, F] = freqz(b, a, 512, fs);

subplot(2, 1, 1);
plot(F, 20*log10(abs(H)));
title('Magnitude Response of High Pass IIR Filter');
xlabel('Frequency (Hz)');
ylabel('Gain (dB)');

subplot(2, 1, 2);
plot(F, angle(H));
title('Phase Response of High Pass IIR Filter');
xlabel('Frequency (Hz)');
ylabel('Phase (Radians)');

