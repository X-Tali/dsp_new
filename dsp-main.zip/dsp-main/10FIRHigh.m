n = 20;
fp = 300;
fq = 200;
fs = 1000;
fn = 2*fp/fs;
window = blackman(n+1);
b = fir1(n, fn, 'high', window);
[H, W] = freqz(b, 1, 128);

subplot(2,1,1);
plot(W/pi, abs(H));
title('Magnitude Response');
xlabel('Normalized Frequency');
ylabel('Gain (dB)');

subplot(2,1,2);
plot(W/pi, angle(H));
title('Phase Response');
xlabel('Normalized Frequency');
ylabel('Angle');
