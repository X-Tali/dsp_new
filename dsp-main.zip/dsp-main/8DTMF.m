
t = -2:0.05:2;
x = input('Enter the input number: ');
fr1 = 697; fr2 = 770; fr3 = 852; fr4 = 941;
fc1 = 1209; fc2 = 1336; fc3 = 1477; fc4 = 1633;
y0 = sin(2*pi*fr4*t) + sin(2*pi*fc2*t);
y1 = sin(2*pi*fr1*t) + sin(2*pi*fc1*t);
y2 = sin(2*pi*fr1*t) + sin(2*pi*fc2*t);
y3 = sin(2*pi*fr1*t) + sin(2*pi*fc3*t);
y4 = sin(2*pi*fr2*t) + sin(2*pi*fc1*t);
y5 = sin(2*pi*fr2*t) + sin(2*pi*fc2*t);
y6 = sin(2*pi*fr2*t) + sin(2*pi*fc3*t);
y7 = sin(2*pi*fr3*t) + sin(2*pi*fc1*t);
y8 = sin(2*pi*fr3*t) + sin(2*pi*fc2*t);
y9 = sin(2*pi*fr3*t) + sin(2*pi*fc3*t);
y_start = sin(2*pi*fr4*t) + sin(2*pi*fc1*t);
y_canc = sin(2*pi*fr4*t) + sin(2*pi*fc3*t);
if x == 1
    plot(t, y1);
elseif x == 2
    plot(t, y2);
elseif x == 3
    plot(t, y3);
elseif x == 4
    plot(t, y4);
elseif x == 5
    plot(t, y5);
elseif x == 6
    plot(t, y6);
elseif x == 7
    plot(t, y7);
elseif x == 8
    plot(t, y8);
elseif x == 9
    plot(t, y9);
elseif x == 0
    plot(t, y0);
elseif x == 11
    plot(t, y_start);
elseif x == 12
    plot(t, y_canc);
else
    disp('Enter the correct input');
end

