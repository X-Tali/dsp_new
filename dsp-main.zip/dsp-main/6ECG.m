
data = readtable('samples.csv');
ECGsignal = data{:, 3};
Fs = 360;
t = (0:length(ECGsignal)-1) / Fs;

plot(t, ECGsignal);
xlabel('Time (seconds)');
ylabel('Amplitude (mV)');
title('ECG Signal');
grid on;